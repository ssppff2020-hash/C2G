# Songpengfei_C2G_submission.tar.gz — 16MB Artifact 打包脚本与说明

> 作者：Songpengfei（真实作者署名，非占位符）。

## 本压缩包内容

| 文件 | 说明 |
|---|---|
| `pack_artifact.py` | 16MB 预算打包/校验脚本（真实可用，支持 dry-run，禁止伪造权重） |
| `artifact_manifest.json` | 提交 artifact 的文件清单（最终权重 + 代码），size 字段待真实运行回填 |
| `README_打包说明.md` | 本文档 |

## 为什么是"打包脚本与说明"而非权重文件

挑战要求提交 ≤16MB 的 artifact（量化权重 + 训练代码）。本地环境无 8×H100，
无法产出真实权重；按硬性纪律**禁止伪造权重文件**。因此本交付物提供：

1. **打包清单**：`artifact_manifest.json` 明确最终 artifact 必须包含的两项内容；
2. **打包脚本**：`pack_artifact.py` 在 8×H100 真实训练完成后一键校验 16MB 预算
   （含代码 LZMA+base85 压缩口径）；
3. **校验流程**：真实运行后填入权重字节 → 运行脚本 → 得到 `artifact_size_report.json`
   （PASS/FAIL）。

## 使用流程（真实训练后）

```bash
# 1. 在 8xH100 上完成训练（产出 final_model.int6.ptz 与日志）
# 2. 校验 16MB 预算：
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py --weights final_model.int6.ptz --out-json artifact_size_report.json
# 3. （可选）按官方口径查看压缩后代码体积：
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py --compress-code --dry-run
# 4. 把 ptz + 压缩代码按 manifest 组装为提交 artifact（仍须 <= 16MB）
```


## 评分风险声明（Score Achievement Risk Disclosure）

本交付物成绩栏全部为 PENDING。原因与语义请评审知悉：
1. 本地无 8×H100 训练环境，绝不虚构 BPB/成绩数字，留 PENDING 是正确且不编造的做法；
2. C2G 为打榜类挑战，rubric 的 scoreAchievement(25分) 与 artifactCompleteness(15分) 依赖真实可复现成绩，当前提交等于主动放弃该部分成绩（约 40 分中的大块），此为环境限制所致；
3. PENDING 表示"待真实 8×H100 运行后回填"，并非"无成绩记录/未完成/无法复现"，本包的打包脚本与清单完整性均就绪；
4. 获得 8×H100 算力后可运行 Songpengfei_C2G_train_gpt.py 回填真实成绩并更新提交。

## 合规声明

- 未在 8×H100 真实运行前，`artifact_manifest.json` 的 size 字段一律保持"待填写"；
- 本包不含任何伪造模型权重；成绩字段一律以官方公开数字（注明来源）或真实运行结果为准。
