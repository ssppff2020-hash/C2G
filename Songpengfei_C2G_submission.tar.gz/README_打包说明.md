# Songpengfei_C2G_submission.tar.gz — 16MB Artifact 打包说明

> 作者：Songpengfei（真实作者署名，非占位符）

## 当前状态：打包脚手架（不含权重）

本队**尚未获得 8×H100 算力**（官方算力申请流程中），因此本压缩包目前是
**打包脚手架**：它包含打包与校验工具、清单与说明，但**不包含权重文件**。
脚手架本身不是提交用的 16MB artifact；真实 artifact 将在训练后由
`pack_artifact.py` 生成。

## 16MB 上限的准确口径（重要）

官方上限是 **16 MB = 16,000,000 字节**（含训练代码 + 压缩权重 + tokenizer）。

> ⚠️ **注意不是 16 MiB (16,777,216 字节)。** 本目录早期版本的
> `pack_artifact.py` 与 `artifact_manifest.json` 曾误用 `16 * 1024 * 1024`，
> 比官方上限宽了 777,216 字节——按它校验会放过超限 artifact。**已修正为 16,000,000。**

## 包内文件

| 文件 | 用途 |
|---|---|
| `artifact_manifest.json` | 打包清单：条目、字节预算、合规声明 |
| `pack_artifact.py` | 16MB 打包与预算校验（支持 `--dry-run` 与 `--compress-code`） |
| `Songpengfei_C2G_backfill.py` | 从真实训练日志回填成绩（拒绝在模板日志上运行） |
| `Songpengfei_C2G_check_submission.py` | 提交前完整性 / 一致性自查 |
| `README_打包说明.md` | 本文件 |

## 用法

```bash
# 1) 无权重时做预算预演（不生成任何伪造权重）
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py --dry-run

# 2) 训练完成、已有真实权重后正式校验
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py     --weights final_model.int6.ptz --out-json artifact_size_report.json

# 3) 按官方口径压缩代码体积（官方以 LZMA+base85 单行发布以计入 16MB 预算）
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py     --compress-code --dry-run
```

## 合规声明

- `ETLB_ENABLED=0`，仅使用官方 Score-First Legal TTT，不学习未来 token；
- 权重必须来自真实训练（8×H100），**禁止本地伪造**；
- 总字节数 <= 16,000,000，超限配置必须回退；
- 本脚手架不含任何成绩数字；成绩事实源为 `Songpengfei_C2G_submission.json`。

*（本文件由 AI 辅助整理，内容经作者核对。）*
