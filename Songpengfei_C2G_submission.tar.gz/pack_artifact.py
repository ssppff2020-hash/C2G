#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pack_artifact.py — Parameter Golf (C2G) 16MB artifact 打包与校验脚本
--------------------------------------------------------------------------------
文件名前缀 SIAS 为占位，可按规范替换为真实姓名拼音。

【用途】
按官方协议校验/生成 16MB 提交 artifact：模型权重（final_model.int6.ptz，
由 Songpengfei_C2G_train_gpt.py 的 serialize() 在训练后自动产出）+ 训练代码。
挑战规定 artifact 总大小上限 16 MB = 16,000,000 字节（含代码 + 压缩权重 + tokenizer）。
注意：16 MB 指的是 16,000,000 字节，不是 16 MiB (16,777,216)；本脚本按官方口径校验。

【本地无 H100 的合规用法】
本脚本支持 --dry-run：不生成任何伪造权重文件，仅根据清单/占位校验打包逻辑，
并输出 16MB 预算报告。真实权重字节数必须来自 8xH100 上的真实训练产物。

【用法示例】
# 1) 训练完成、已有真实权重时，正式打包校验：
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py \\
    --weights final_model.int6.ptz --out-json artifact_size_report.json

# 2) 本地无 H100，仅做预算预演（dry-run）：
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py --dry-run

# 3) 若需按官方口径压缩代码体积（官方以 LZMA+base85 单行发布以计入 16MB 预算）：
python pack_artifact.py --code Songpengfei_C2G_train_gpt.py --compress-code --dry-run
"""
import argparse, base64, json, lzma, os, pathlib, sys

MAX_ARTIFACT_BYTES = 16_000_000  # 官方上限：16 MB = 16,000,000 字节（注意不是 16 MiB）

def compress_code_lzma_b85(code_text):
    """将训练代码压缩为 LZMA + base85 单行（官方发布口径），返回 (blob_str, byte_len)。"""
    raw = code_text.encode("utf-8")
    blob = lzma.compress(raw, preset=9)
    return base64.b85encode(blob).decode("ascii"), len(blob)

def main():
    ap = argparse.ArgumentParser(description="Parameter Golf (C2G) 16MB artifact 打包与校验")
    ap.add_argument("--code", required=True, help="训练代码文件路径（计入 16MB 预算）")
    ap.add_argument("--weights", default=None, help="真实量化权重文件 final_model.int6.ptz；dry-run 时可不传")
    ap.add_argument("--dry-run", action="store_true", help="仅做预算预演，不要求真实权重文件")
    ap.add_argument("--compress-code", action="store_true", help="以 LZMA+base85 单行口径计算代码体积（官方口径）")
    ap.add_argument("--out-json", default="artifact_size_report.json", help="输出预算报告 JSON 路径")
    args = ap.parse_args()

    code = pathlib.Path(args.code)
    if not code.exists():
        sys.exit(f"ERROR: 找不到训练代码文件: {code}")
    code_bytes_raw = code.stat().st_size
    code_bytes = code_bytes_raw
    code_note = "raw utf-8"
    if args.compress_code:
        _, code_bytes = compress_code_lzma_b85(code.read_text(encoding="utf-8"))
        code_note = "lzma+b85 single-line (official style)"

    weights_bytes = 0
    weights_note = "MISSING"
    if args.weights:
        w = pathlib.Path(args.weights)
        if not w.exists():
            sys.exit(f"ERROR: 找不到权重文件: {w}")
        weights_bytes = w.stat().st_size
        weights_note = "present"
    elif not args.dry_run:
        sys.exit("ERROR: 必须提供 --weights（真实权重文件）或以 --dry-run 模式运行（禁止伪造权重）")

    total = code_bytes + weights_bytes
    ok = total <= MAX_ARTIFACT_BYTES
    report = {
        "max_artifact_bytes": MAX_ARTIFACT_BYTES,
        "code_path": str(code),
        "code_bytes": code_bytes,
        "code_bytes_note": code_note,
        "weights_path": args.weights,
        "weights_bytes": weights_bytes,
        "weights_note": weights_note,
        "total_bytes": total,
        "within_16mb": ok,
        "headroom_bytes": MAX_ARTIFACT_BYTES - total,
        "status": "DRY_RUN" if (args.dry_run or weights_note == "MISSING") else "VALIDATED",
        "warning": "本地无 H100 时成绩类字段严禁填写；真实权重字节数须来自 8xH100 真实训练产物"
    }
    out = pathlib.Path(args.out_json)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(f"\n{'PASS' if ok else 'FAIL'} total={total} / {MAX_ARTIFACT_BYTES} bytes")
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
